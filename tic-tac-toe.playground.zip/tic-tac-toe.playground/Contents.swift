enum Symbol : String {
    case X = "❌"
    case O = "⭕️"
    case Free = "⬜️"
}


struct Game {
    
    var desk = [[Symbol.Free, Symbol.Free, Symbol.Free],
                [Symbol.Free, Symbol.Free, Symbol.Free],
                [Symbol.Free, Symbol.Free, Symbol.Free]]
    
    func show() {
        for i in desk {
            for j in i {
                print(j.rawValue, terminator: " ")
            }
            print("")
        }
    }
    
    
    subscript(image: Symbol, row: Int, column: Int) -> String {
        mutating get {
            for line in 0..<3 {
                if line == row - 1{
                    for i in 0..<3 {
                        if i == column - 1 && desk[row - 1][column - 1] == .Free {
                            desk[row - 1][column - 1] = image
                            return desk[line][i].rawValue
                        }
                        
                    }
                    
                }
            }
            return Symbol.Free.rawValue
        }
    }
    
}


var q = Game()
q[.O, 2, 2]
q.show()
print("")
q[.X, 2, 2]
q.show()
print("")
q[.X, 1, 2]
q.show()
print("")
q[.O, 3, 3]
q.show()
print("")
q[.X, 1, 3]
q.show()

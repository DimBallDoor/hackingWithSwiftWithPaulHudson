enum Images: String {
    case Player = "🤓"
    case Box = "💰"
    case Wall = "⬛️"
    case NotWall = "⬜️"
    case WinBox = "💎"
    case Target = "🟨"
}

enum To {
    case Left
    case Right
    case Up
    case Down
}


struct Position {
    var x: Int
    var y: Int
    
    mutating func moveTo(x: Int, andY y: Int) {
        self = Position(x: self.x + x, y: self.y + y)
    }
}


struct Box {
    var image = Images.Box.rawValue
    var position: Position
}

struct Player {
    var image = Images.Player.rawValue
    var position: Position
}

struct Target {
    var image = Images.Target.rawValue
    var position: Position
}


struct Room {
    
    let w: Int
    let h: Int
    
    var player = Player(position: Position(x: 1, y: 1))
    var box = Box(position: Position(x: 2, y: 2))
    var target = Target(position: Position(x: 3, y: 3))
    
    
    mutating func printRoom() {
        
        var str = ""
        for i in 0...h + 1 {
            for j in 0...w + 1 {
                switch (i, j) {
                case (0, _):
                    str += Images.Wall.rawValue
                case (_, 0):
                    str += Images.Wall.rawValue
                case (h + 1, _):
                    str += Images.Wall.rawValue
                case (_, w + 1):
                    str += Images.Wall.rawValue
                case (target.position.y, target.position.x):
                    if (target.position.y, target.position.x) == (player.position.y, player.position.x) {
                        target.image = Images.Player.rawValue
                    } else if (target.position.y, target.position.x) == (box.position.y, box.position.x) {
                        target.image = Images.WinBox.rawValue
                    } else {
                        target.image = Images.Target.rawValue
                    }
                    str += target.image
                case (player.position.y, player.position.x):
                    str += Images.Player.rawValue
                case (box.position.y, box.position.x):
                    str += Images.Box.rawValue
                default:
                    str += Images.NotWall.rawValue
                }
            }
            print(str)
            str = ""
        }
        
    }
    
    func boxNearWall(about: To) -> Bool {
        
        switch about {
        case .Down:
            if box.position.y == h {
                return true
            }
        case .Up:
            if box.position.y == 1 {
                return true
            }
        case .Left:
            if box.position.x == 1 {
                return true
            }
        case .Right:
            if box.position.x == w {
                return true
            }
        }
        return false
    }
    
    func playerNearWall(about: To) -> Bool {
        
        switch about {
        case .Down:
            if player.position.y == h {
                return true
            }
        case .Up:
            if player.position.y == 1 {
                return true
            }
        case .Left:
            if player.position.x == 1 {
                return true
            }
        case .Right:
            if player.position.x == w {
                return true
            }
        }
        return false
    }
    
    func checkBoxNearPlayer(about: To) -> Bool {
        
        switch about {
        case .Down:
            if player.position.y + 1 == box.position.y && player.position.x == box.position.x {
                return true
            }
        case .Up:
            if player.position.y - 1 == box.position.y && player.position.x == box.position.x {
                return true
            }
        case .Left:
            if player.position.x - 1 == box.position.x && player.position.y == box.position.y {
                return true
            }
        case .Right:
            if player.position.x + 1 == box.position.x && player.position.y == box.position.y {
                return true
            }
        }
        return false
    }
    
    mutating func go(to: To) {
        switch to {
        case .Down:
            if boxNearWall(about: .Down) == false && checkBoxNearPlayer(about: .Down) == true {
                box.position.y += 1
                player.position.y += 1
            } else if playerNearWall(about: .Down) == false && checkBoxNearPlayer(about: .Down) == false {
                player.position.y += 1
            }
            
        case .Up:
            if boxNearWall(about: .Up) == false && checkBoxNearPlayer(about: .Up) == true {
                box.position.y -= 1
                player.position.y -= 1
            } else if playerNearWall(about: .Up) == false && checkBoxNearPlayer(about: .Up) == false {
                player.position.y -= 1
            }
            
        case .Left:
            if boxNearWall(about: .Left) == false && checkBoxNearPlayer(about: .Left) == true {
                box.position.x -= 1
                player.position.x -= 1
            } else if playerNearWall(about: .Left) == false && checkBoxNearPlayer(about: .Left) == false {
                player.position.x -= 1
            }
        case .Right:
            if boxNearWall(about: .Right) == false && checkBoxNearPlayer(about: .Right) == true {
                box.position.x += 1
                player.position.x += 1
            } else if playerNearWall(about: .Right) == false && checkBoxNearPlayer(about: .Right) == false {
                player.position.x += 1
            }
        }
    }
}






// let's game =)

var room1 = Room(w: 5, h: 5)
room1.printRoom()

room1.go(to: .Down)
room1.printRoom()

room1.go(to: .Right)
room1.printRoom()

room1.go(to: .Up)
room1.printRoom()

room1.go(to: .Right)
room1.printRoom()

room1.go(to: .Down)
room1.printRoom()

room1.go(to: .Left)
room1.printRoom()


room1.go(to: .Up)
room1.printRoom()

room1.go(to: .Up)
room1.printRoom()
room1.go(to: .Left)
room1.printRoom()
room1.go(to: .Left)
room1.printRoom()
